// Main application functionality
class TikTokClone {
    constructor() {
        this.currentVideo = null;
        this.videos = [];
        this.isPlaying = false;
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.loadVideos();
        this.setupVideoAutoPlay();
    }

    setupEventListeners() {
        // Upload modal
        const uploadBtn = document.querySelector('.upload-btn');
        const closeBtn = document.querySelector('.close-btn');
        const modal = document.getElementById('uploadModal');

        uploadBtn.addEventListener('click', () => {
            modal.style.display = 'block';
        });

        closeBtn.addEventListener('click', () => {
            modal.style.display = 'none';
        });

        // Close modal when clicking outside
        window.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.style.display = 'none';
            }
        });

        // Like button functionality
        document.querySelectorAll('.like-btn').forEach(btn => {
            btn.addEventListener('click', this.handleLike.bind(this));
        });

        // Follow button functionality
        document.querySelectorAll('.follow-btn').forEach(btn => {
            btn.addEventListener('click', this.handleFollow.bind(this));
        });

        // Sidebar navigation
        document.querySelectorAll('.sidebar-item').forEach(item => {
            item.addEventListener('click', this.handleNavigation.bind(this));
        });
    }

    handleLike(event) {
        const btn = event.currentTarget;
        const countElement = btn.querySelector('.action-count');
        let count = parseInt(countElement.textContent) || 0;
        
        if (btn.classList.contains('liked')) {
            count--;
            btn.classList.remove('liked');
        } else {
            count++;
            btn.classList.add('liked');
        }
        
        countElement.textContent = this.formatCount(count);
    }

    handleFollow(event) {
        const btn = event.currentTarget;
        if (btn.textContent === 'Follow') {
            btn.textContent = 'Following';
            btn.style.backgroundColor = '#2f2f2f';
        } else {
            btn.textContent = 'Follow';
            btn.style.backgroundColor = '#ff0050';
        }
    }

    handleNavigation(event) {
        // Remove active class from all items
        document.querySelectorAll('.sidebar-item').forEach(item => {
            item.classList.remove('active');
        });
        
        // Add active class to clicked item
        event.currentTarget.classList.add('active');
        
        // Here you would typically load different content based on navigation
        console.log('Navigated to:', event.currentTarget.textContent.trim());
    }

    setupVideoAutoPlay() {
        const videos = document.querySelectorAll('.video-player');
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.play();
                } else {
                    entry.target.pause();
                }
            });
        }, { threshold: 0.8 });

        videos.forEach(video => {
            observer.observe(video);
        });
    }

    loadVideos() {
        // Simulate loading videos from an API
        this.videos = [
            {
                id: 1,
                username: '@username1',
                description: 'Video description goes here...',
                likes: 1200,
                comments: 245,
                shares: 89
            },
            {
                id: 2,
                username: '@username2',
                description: 'Another amazing video! #trending',
                likes: 3400,
                comments: 567,
                shares: 234
            }
        ];
    }

    formatCount(count) {
        if (count >= 1000000) {
            return (count / 1000000).toFixed(1) + 'M';
        } else if (count >= 1000) {
            return (count / 1000).toFixed(1) + 'K';
        }
        return count.toString();
    }

    // Method to simulate video upload
    simulateUpload(file) {
        console.log('Uploading file:', file.name);
        // In a real app, you would upload to a server here
        return new Promise((resolve) => {
            setTimeout(() => {
                resolve({ success: true, message: 'Upload successful!' });
            }, 2000);
        });
    }
}

// Initialize the app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.tiktokApp = new TikTokClone();
});

// Utility functions
const Utils = {
    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    },

    formatTime(seconds) {
        const mins = Math.floor(seconds / 60);
        const secs = Math.floor(seconds % 60);
        return `${mins}:${secs.toString().padStart(2, '0')}`;
    },

    generateId() {
        return Math.random().toString(36).substr(2, 9);
    }
};