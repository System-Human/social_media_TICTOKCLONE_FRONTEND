// Enhanced video player functionality
class VideoPlayer {
    constructor() {
        this.players = new Map();
        this.setupVideoPlayers();
    }

    setupVideoPlayers() {
        document.querySelectorAll('.video-player').forEach((video, index) => {
            this.setupSinglePlayer(video, index);
        });
    }

    setupSinglePlayer(video, index) {
        const playerId = `player-${index}`;
        video.id = playerId;
        
        this.players.set(playerId, {
            element: video,
            isPlaying: false,
            currentTime: 0,
            duration: 0
        });

        // Add event listeners
        video.addEventListener('loadedmetadata', () => {
            this.players.get(playerId).duration = video.duration;
        });

        video.addEventListener('timeupdate', () => {
            this.players.get(playerId).currentTime = video.currentTime;
            this.updateProgressBar(video);
        });

        video.addEventListener('play', () => {
            this.players.get(playerId).isPlaying = true;
            this.pauseOtherVideos(playerId);
        });

        video.addEventListener('pause', () => {
            this.players.get(playerId).isPlaying = false;
        });

        video.addEventListener('ended', () => {
            video.currentTime = 0;
            video.play();
        });

        // Add click to play/pause
        video.addEventListener('click', () => {
            if (video.paused) {
                video.play();
            } else {
                video.pause();
            }
        });

        // Add double click for like
        video.addEventListener('dblclick', () => {
            this.handleDoubleClickLike(video);
        });
    }

    updateProgressBar(video) {
        const progress = (video.currentTime / video.duration) * 100;
        let progressBar = video.parentElement.querySelector('.video-progress-bar');
        
        if (!progressBar) {
            const progressContainer = document.createElement('div');
            progressContainer.className = 'video-progress';
            progressBar = document.createElement('div');
            progressBar.className = 'video-progress-bar';
            progressContainer.appendChild(progressBar);
            video.parentElement.appendChild(progressContainer);
        }
        
        progressBar.style.width = `${progress}%`;
    }

    pauseOtherVideos(currentPlayerId) {
        this.players.forEach((player, playerId) => {
            if (playerId !== currentPlayerId && player.isPlaying) {
                player.element.pause();
                player.isPlaying = false;
            }
        });
    }

    handleDoubleClickLike(video) {
        const videoCard = video.closest('.video-card');
        const likeBtn = videoCard.querySelector('.like-btn');
        
        // Trigger like animation
        likeBtn.classList.add('liked');
        
        // Update like count
        const countElement = likeBtn.querySelector('.action-count');
        let count = parseInt(countElement.textContent) || 0;
        count++;
        countElement.textContent = window.tiktokApp.formatCount(count);
        
        // Show heart animation
        this.showHeartAnimation(video, event);
    }

    showHeartAnimation(video, event) {
        const heart = document.createElement('div');
        heart.innerHTML = '❤️';
        heart.style.position = 'absolute';
        heart.style.fontSize = '40px';
        heart.style.pointerEvents = 'none';
        heart.style.zIndex = '1000';
        
        const rect = video.getBoundingClientRect();
        heart.style.left = (event.clientX - rect.left - 20) + 'px';
        heart.style.top = (event.clientY - rect.top - 20) + 'px';
        
        video.parentElement.appendChild(heart);
        
        // Animate heart
        heart.animate([
            { transform: 'scale(0)', opacity: 1 },
            { transform: 'scale(1.5)', opacity: 0.7 },
            { transform: 'scale(1)', opacity: 1 },
            { transform: 'scale(1.5) translateY(-50px)', opacity: 0 }
        ], {
            duration: 1000,
            easing: 'ease-out'
        });
        
        setTimeout(() => heart.remove(), 1000);
    }

    // Method to load new video
    loadVideo(src, autoplay = true) {
        const video = document.createElement('video');
        video.className = 'video-player';
        video.controls = true;
        video.muted = true;
        video.loop = true;
        
        const source = document.createElement('source');
        source.src = src;
        source.type = 'video/mp4';
        
        video.appendChild(source);
        
        if (autoplay) {
            video.autoplay = true;
        }
        
        return video;
    }
}

// Initialize video players when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.videoPlayer = new VideoPlayer();
});