// User interactions and social features
class Interactions {
    constructor() {
        this.comments = new Map();
        this.shares = new Map();
        this.setupInteractions();
    }

    setupInteractions() {
        this.setupCommentSystem();
        this.setupShareSystem();
        this.setupSearch();
        this.setupInfiniteScroll();
    }

    setupCommentSystem() {
        document.querySelectorAll('.comment-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const videoCard = e.target.closest('.video-card');
                this.showComments(videoCard);
            });
        });
    }

    showComments(videoCard) {
        // Create comments modal
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.id = 'commentsModal';
        
        const videoId = videoCard.querySelector('.video-player').id;
        const comments = this.getComments(videoId);
        
        modal.innerHTML = `
            <div class="modal-content" style="max-width: 400px;">
                <span class="close-btn">&times;</span>
                <h3>Comments</h3>
                <div class="comments-list">
                    ${comments.map(comment => `
                        <div class="comment-item">
                            <img src="${comment.avatar}" alt="User" class="comment-avatar">
                            <div class="comment-content">
                                <strong>${comment.username}</strong>
                                <p>${comment.text}</p>
                                <span class="comment-time">${comment.time}</span>
                            </div>
                        </div>
                    `).join('')}
                </div>
                <div class="comment-input">
                    <input type="text" placeholder="Add a comment..." class="comment-text">
                    <button class="post-comment-btn">Post</button>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        modal.style.display = 'block';
        
        // Close modal
        modal.querySelector('.close-btn').addEventListener('click', () => {
            modal.remove();
        });
        
        // Post comment
        modal.querySelector('.post-comment-btn').addEventListener('click', () => {
            this.postComment(videoId, modal.querySelector('.comment-text').value);
            modal.remove();
        });
    }

    getComments(videoId) {
        // Mock comments data
        return [
            {
                username: '@user1',
                avatar: 'assets/images/user1.jpg',
                text: 'This is amazing! 👏',
                time: '2 hours ago'
            },
            {
                username: '@user2',
                avatar: 'assets/images/user2.jpg',
                text: 'Love this content! ❤️',
                time: '1 hour ago'
            }
        ];
    }

    postComment(videoId, commentText) {
        if (!commentText.trim()) return;
        
        console.log(`Posted comment on video ${videoId}: ${commentText}`);
        // In real app, send to backend API
        
        // Update comment count
        const commentBtn = document.querySelector(`#${videoId}`).closest('.video-card').querySelector('.comment-btn');
        const countElement = commentBtn.querySelector('.action-count');
        let count = parseInt(countElement.textContent) || 0;
        count++;
        countElement.textContent = window.tiktokApp.formatCount(count);
    }

    setupShareSystem() {
        document.querySelectorAll('.share-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const videoCard = e.target.closest('.video-card');
                this.showShareOptions(videoCard);
            });
        });
    }

    showShareOptions(videoCard) {
        const shareOptions = ['Copy Link', 'Share to Facebook', 'Share to Twitter', 'Embed Video'];
        
        const modal = document.createElement('div');
        modal.className = 'modal';
        
        modal.innerHTML = `
            <div class="modal-content" style="max-width: 300px;">
                <span class="close-btn">&times;</span>
                <h3>Share Video</h3>
                <div class="share-options">
                    ${shareOptions.map(option => `
                        <div class="share-option">${option}</div>
                    `).join('')}
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        modal.style.display = 'block';
        
        modal.querySelector('.close-btn').addEventListener('click', () => {
            modal.remove();
        });
        
        // Handle share option clicks
        modal.querySelectorAll('.share-option').forEach(option => {
            option.addEventListener('click', () => {
                this.handleShare(option.textContent, videoCard);
                modal.remove();
            });
        });
    }

    handleShare(platform, videoCard) {
        console.log(`Sharing to: ${platform}`);
        // Update share count
        const shareBtn = videoCard.querySelector('.share-btn');
        const countElement = shareBtn.querySelector('.action-count');
        let count = parseInt(countElement.textContent) || 0;
        count++;
        countElement.textContent = window.tiktokApp.formatCount(count);
    }

    setupSearch() {
        const searchInput = document.querySelector('.search-input');
        searchInput.addEventListener('input', Utils.debounce((e) => {
            this.performSearch(e.target.value);
        }, 300));
    }

    performSearch(query) {
        if (query.length < 2) return;
        
        console.log('Searching for:', query);
        // In real app, make API call to search endpoint
    }

    setupInfiniteScroll() {
        const videoFeed = document.querySelector('.video-feed');
        let loading = false;
        
        videoFeed.addEventListener('scroll', Utils.debounce(() => {
            const { scrollTop, scrollHeight, clientHeight } = videoFeed;
            
            if (scrollTop + clientHeight >= scrollHeight - 100 && !loading) {
                this.loadMoreVideos();
            }
        }, 100));
    }

    loadMoreVideos() {
        console.log('Loading more videos...');
        // In real app, fetch next page of videos from API
    }
}

// Initialize interactions
document.addEventListener('DOMContentLoaded', () => {
    window.interactions = new Interactions();
});